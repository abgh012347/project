package phone_app;
import java.util.Scanner;

public class Total_Lobby {
	public static Phone_Manager manager = new Phone_Manager();

    public Total_Lobby() {
        

       
    }

    public static void main(String[] args) {
    	manager.Main_Menu_Open();
    }
}